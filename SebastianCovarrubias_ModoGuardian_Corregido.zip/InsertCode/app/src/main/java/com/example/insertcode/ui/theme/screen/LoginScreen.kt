package com.example.insertcode.ui.theme.screen

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.insertcode.viewmodel.LoginViewModel

@Composable
fun LoginScreen(
    viewModel: LoginViewModel,
    isCompact: Boolean = true // Se conectará más adelante con WindowSizeUtils
) {
    val estado by viewModel.estado.collectAsState()

    if (isCompact) {
        // LAYOUT COMPACTO (Celular tradicional en vertical)
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            LoginFormContent(estado, viewModel)
        }
    } else {
        // LAYOUT MEDIUM/EXPANDED (Tablet o Pantalla Horizontal)
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Card(
                modifier = Modifier.widthIn(max = 450.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    LoginFormContent(estado, viewModel)
                }
            }
        }
    }
}

@Composable
fun LoginFormContent(
    estado: com.example.insertcode.model.LoginUiState,
    viewModel: LoginViewModel
) {
    Text(
        text = "Caso Modo Guardián",
        style = MaterialTheme.typography.headlineMedium,
        modifier = Modifier.padding(bottom = 24.dp)
    )

    // ========== CAMPO EMAIL ==========
    OutlinedTextField(
        value = estado.email,
        onValueChange = viewModel::onEmailChange,
        label = { Text("Correo electrónico") },
        isError = estado.errores.email != null,
        supportingText = {
            estado.errores.email?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        },
        modifier = Modifier.fillMaxWidth()
    )

    Spacer(modifier = Modifier.height(8.dp))

    // ========== CAMPO CONTRASEÑA ==========
    OutlinedTextField(
        value = estado.password,
        onValueChange = viewModel::onPasswordChange,
        label = { Text("Contraseña") },
        visualTransformation = PasswordVisualTransformation(),
        isError = estado.errores.password != null,
        supportingText = {
            estado.errores.password?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        },
        modifier = Modifier.fillMaxWidth()
    )

    Spacer(modifier = Modifier.height(24.dp))

    // BOTÓN INICIAR SESIÓN: siempre disponible (habilitado), sin depender del texto escrito.
    // Si los campos están vacíos, la validación del ViewModel muestra los errores correspondientes.
    Button(
        onClick = { viewModel.validarFormulario() },
        enabled = true,
        modifier = Modifier.fillMaxWidth()
    ) {
        Text("Iniciar Sesión")
    }

    // Indicador de progreso mientras se validan las credenciales
    if (estado.isLoading) {
        Spacer(modifier = Modifier.height(16.dp))
        CircularProgressIndicator()
    }
}
