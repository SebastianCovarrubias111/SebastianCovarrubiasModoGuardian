package com.example.insertcode.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.insertcode.ui.theme.screen.LoginScreen
import com.example.insertcode.viewmodel.LoginViewModel

// 1. Definición de las pantallas del sistema (Sealed Class oficial)
sealed class Screen(val route: String) {
    data object Login : Screen("login")
    data object HomeAdmin : Screen("home_admin")
    data object HomeSupervisor : Screen("home_supervisor")
    data object HomeOperator : Screen("home_operator")
}

// 2. Eventos de navegación reactiva despachados por el ViewModel
sealed class NavigationEvent {
    data class NavigateTo(val route: String) : NavigationEvent()
    data object NavigateBack : NavigationEvent()
    // Cierre de sesión: vuelve al Login y limpia toda la pila de navegación
    data object Logout : NavigationEvent()
}

@Composable
fun AppNavigation(
    navController: NavHostController,
    loginViewModel: LoginViewModel
) {
    NavHost(
        navController = navController,
        startDestination = Screen.Login.route // Inicia directamente en el Login
    ) {
        // Pantalla de Login Principal
        composable(route = Screen.Login.route) {
            LoginScreen(viewModel = loginViewModel)
        }

        // Pantalla de Inicio para el Rol Administrador
        composable(route = Screen.HomeAdmin.route) {
            // Aquí puedes crear o invocar a tu HomeAdminScreen
            com.example.insertcode.ui.theme.screen.HomeAdminScreen(loginViewModel)
        }

        // Pantalla de Inicio para el Rol Supervisor
        composable(route = Screen.HomeSupervisor.route) {
            com.example.insertcode.ui.theme.screen.HomeSupervisorScreen(loginViewModel)
        }

        // Pantalla de Inicio para el Rol Operador
        composable(route = Screen.HomeOperator.route) {
            com.example.insertcode.ui.theme.screen.HomeOperatorScreen(loginViewModel)
        }
    }
}
