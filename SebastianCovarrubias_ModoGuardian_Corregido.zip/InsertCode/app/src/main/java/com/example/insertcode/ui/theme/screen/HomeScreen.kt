package com.example.insertcode.ui.theme.screen

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.insertcode.viewmodel.LoginViewModel

@Composable
fun HomeAdminScreen(viewModel: LoginViewModel) {
    val estado by viewModel.estado.collectAsState()

    // El botón "atrás" del sistema también cierra sesión y limpia los datos
    BackHandler { viewModel.cerrarSesion() }

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Panel de Administración", style = MaterialTheme.typography.headlineLarge)
        Spacer(modifier = Modifier.height(8.dp))
        Text("Usuario autenticado: ${estado.email}")
        Text("Rol asignado: ${estado.rol}")
        Spacer(modifier = Modifier.height(24.dp))
        Button(onClick = { viewModel.cerrarSesion() }) {
            Text("Cerrar Sesión")
        }
    }
}

@Composable
fun HomeSupervisorScreen(viewModel: LoginViewModel) {
    val estado by viewModel.estado.collectAsState()

    // El botón "atrás" del sistema también cierra sesión y limpia los datos
    BackHandler { viewModel.cerrarSesion() }

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Módulo de Supervisión", style = MaterialTheme.typography.headlineLarge)
        Spacer(modifier = Modifier.height(8.dp))
        Text("Usuario autenticado: ${estado.email}")
        Text("Rol asignado: ${estado.rol}")
        Spacer(modifier = Modifier.height(24.dp))
        Button(onClick = { viewModel.cerrarSesion() }) {
            Text("Cerrar Sesión")
        }
    }
}

@Composable
fun HomeOperatorScreen(viewModel: LoginViewModel) {
    val estado by viewModel.estado.collectAsState()

    // El botón "atrás" del sistema también cierra sesión y limpia los datos
    BackHandler { viewModel.cerrarSesion() }

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Consola de Operador", style = MaterialTheme.typography.headlineLarge)
        Spacer(modifier = Modifier.height(8.dp))
        Text("Usuario autenticado: ${estado.email}")
        Text("Rol asignado: ${estado.rol}")
        Spacer(modifier = Modifier.height(24.dp))
        Button(onClick = { viewModel.cerrarSesion() }) {
            Text("Cerrar Sesión")
        }
    }
}

