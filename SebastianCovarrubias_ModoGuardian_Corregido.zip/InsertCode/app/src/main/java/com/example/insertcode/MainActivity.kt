package com.example.insertcode

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.navigation.compose.rememberNavController
import com.example.insertcode.navigation.AppNavigation
import com.example.insertcode.navigation.NavigationEvent
import com.example.insertcode.navigation.Screen
import com.example.insertcode.ui.theme.InsertCodeTheme
import com.example.insertcode.viewmodel.LoginViewModel

class MainActivity : ComponentActivity() {

    // Instanciamos el LoginViewModel en la actividad principal para compartirlo
    private val loginViewModel: LoginViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            InsertCodeTheme {
                val navController = rememberNavController()

                // LaunchedEffect que colecta los eventos de navegación reactiva del ViewModel
                LaunchedEffect(key1 = true) {
                    loginViewModel.eventosNavegacion.collect { evento ->
                        when (evento) {
                            is NavigationEvent.NavigateTo -> {
                                navController.navigate(evento.route) {
                                    // Evita acumular pantallas repetidas en la pila
                                    launchSingleTop = true
                                }
                            }
                            is NavigationEvent.NavigateBack -> {
                                navController.popBackStack()
                            }
                            is NavigationEvent.Logout -> {
                                // Vuelve al Login y elimina las pantallas anteriores de la pila
                                navController.navigate(Screen.Login.route) {
                                    popUpTo(navController.graph.id) { inclusive = true }
                                    launchSingleTop = true
                                }
                            }
                        }
                    }
                }

                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(paddingValues = innerPadding)
                    ) {
                        // Pasamos el navController y el viewModel requeridos por la rúbrica
                        AppNavigation(
                            navController = navController,
                            loginViewModel = loginViewModel
                        )
                    }
                }
            }
        }
    }
}
