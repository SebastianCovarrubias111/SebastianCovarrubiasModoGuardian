package com.example.insertcode.model

// Estado global para el formulario de login y control de rol
data class LoginUiState(
    val email: String = "",
    val password: String = "",
    val isLoading: Boolean = false,
    val rol: String? = null, // Puede ser "Admin", "Supervisor", "Operador" o null
    val errores: LoginErrores = LoginErrores()
)

// Mensajes de error individuales para los campos de entrada
data class LoginErrores(
    val email: String? = null,
    val password: String? = null
)

